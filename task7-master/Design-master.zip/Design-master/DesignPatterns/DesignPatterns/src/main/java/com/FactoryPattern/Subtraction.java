package com.FactoryPattern;

public class Subtraction implements Calculate{
	public void calculate(float a, float b) {
		System.out.println("subtraction is "+(a-b));
	}

}
