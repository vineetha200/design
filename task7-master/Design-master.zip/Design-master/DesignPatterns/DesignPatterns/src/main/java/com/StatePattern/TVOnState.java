package com.StatePattern;
public class TVOnState implements State {
	
	public void perform() {
		System.out.println("TV is turned ON");
	}

}